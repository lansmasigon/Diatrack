import React, { useState, useEffect } from "react";
import supabase from "./supabaseClient";
import "./Dashboard.css";

const Dashboard = ({ user, onLogout }) => {
  const [activeSection, setActiveSection] = useState("doctor-dashboard");
  const [patients, setPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [patientMetrics, setPatientMetrics] = useState([]);
  const [editingPatientDetails, setEditingPatientDetails] = useState(false);
  const [editedPatientData, setEditedPatientData] = useState({});

  useEffect(() => {
    if (activeSection === "doctor-dashboard") {
      fetchPatients();
    } else if (activeSection === "patient-profile" && selectedPatient) {
      fetchPatientDetails(selectedPatient.patient_id);
      setEditedPatientData({ ...selectedPatient });
    }
  }, [activeSection, user.doctor_id, selectedPatient]);

  const fetchPatients = async () => {
    setLoading(true);
    setError("");
    try {
      if (!user || !user.doctor_id) {
        setError("Doctor ID is not available.");
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("patients")
        .select("*")
        .eq("preferred_doctor_id", user.doctor_id)
        .order("patient_id", { ascending: true });

      if (error) throw error;
      setPatients([...data]);
    } catch (err) {
      setError("Error fetching data: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchPatientDetails = async (patientId) => {
    setLoading(true);
    setError("");
    try {
      const { data: metrics, error: metricsError } = await supabase
        .from("health_metrics")
        .select("*")
        .eq("patient_id", patientId);

      if (metricsError) throw metricsError;
      setPatientMetrics(metrics);
    } catch (err) {
      setError("Error fetching patient details: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    onLogout();
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleViewClick = (patient) => {
    setSelectedPatient(patient);
    setActiveSection("patient-profile");
  };

  const handleDeleteClick = async (patient) => {
    if (window.confirm(`Are you sure you want to delete patient ${patient.first_name} ${patient.last_name}?`)) {
      setLoading(true);
      setError("");
      try {
        const { error } = await supabase
          .from("patients")
          .delete()
          .eq("patient_id", patient.patient_id);

        if (error) {
          console.error("Supabase Delete Error:", error);
          setError(`Error deleting patient: ${error.message}`);
        } else {
          alert("Patient deleted successfully!");
          fetchPatients();
        }
      } catch (err) {
        console.error("Frontend Delete Error:", err);
        setError("Error deleting patient: " + err.message);
      } finally {
        setLoading(false);
      }
    }
  };

  const handlePatientInputChange = (e) => {
    const { name, value } = e.target;
    setEditedPatientData({ ...editedPatientData, [name]: value });
  };

  const handleUpdatePatientDetails = async () => {
    setLoading(true);
    setError("");
    try {
      const { data, error } = await supabase
        .from("patients")
        .update(editedPatientData)
        .match({ patient_id: selectedPatient.patient_id })
        .select();

      if (error) {
        console.error("Supabase Update Error:", error);
        setError("Error updating patient details: " + error.message);
        return;
      }

      setSelectedPatient(data[0]);
      setEditingPatientDetails(false);
      alert("Patient details updated successfully!");
    } catch (err) {
      console.error("Frontend Update Error:", err);
      setError("Error updating patient details: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredPatients = patients.filter((patient) =>
    `${patient.first_name} ${patient.last_name}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderDoctorDashboard = () => {
    if (loading) return <div>Loading patients...</div>;
    if (error) return <div className="error-message">{error}</div>;
    if (filteredPatients.length === 0 && searchTerm) return <div>No patients found matching your search.</div>;
    if (patients.length === 0 && !searchTerm) return <div>No patients found assigned to you.</div>;

    return (
      <div>
        <h2>My Patients</h2>
        <table className="patient-list">
          <thead>
            <tr>
              <th>Patient ID</th>
              <th>Patient Name</th>
              <th>Date of Birth</th>
              <th>Contact Info</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPatients.map((patient) => (
              <tr key={patient.patient_id}>
                <td>{patient.patient_id}</td>
                <td>{patient.first_name} {patient.last_name}</td>
                <td>{patient.date_of_birth}</td>
                <td>{patient.contact_info}</td>
                <td>
                  <button className="action-button view-button" onClick={() => handleViewClick(patient)}>View</button>
                  <button className="action-button delete-button" onClick={() => handleDeleteClick(patient)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderPatientProfile = () => {
    if (loading) return <div>Loading patient details...</div>;
    if (error) return <div className="error-message">{error}</div>;

    return (
      <div>
        <h2>Patient Profile: {selectedPatient.first_name} {selectedPatient.last_name}</h2>

        <h3>Health Metrics</h3>
        {patientMetrics.length > 0 ? (
          <table className="patient-metrics">
            <thead>
              <tr>
                <th>Metric ID</th>
                <th>Submission Date</th>
                <th>Blood Glucose</th>
                <th>BP Systolic</th>
                <th>BP Diastolic</th>
                <th>Pulse Rate</th>
                <th>Wound Photo</th>
                <th>Food Photo</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {patientMetrics.map((metric) => (
                <tr key={metric.metric_id}>
                  <td>{metric.metric_id}</td>
                  <td>{metric.submission_date}</td>
                  <td>{metric.blood_glucose}</td>
                  <td>{metric.bp_systolic}</td>
                  <td>{metric.bp_diastolic}</td>
                  <td>{metric.pulse_rate}</td>
                  <td>{metric.wound_photo_url && <img src={metric.wound_photo_url} alt="Wound" style={{ maxWidth: '50px' }} />}</td>
                  <td>{metric.food_photo_url && <img src={metric.food_photo_url} alt="Food" style={{ maxWidth: '50px' }} />}</td>
                  <td>{metric.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div>No health metrics found.</div>
        )}

        <h3>Patient Details</h3>
        <table className="patient-details">
          <thead>
            <tr>
              <th>Risk</th>
              <th>Medication</th>
              <th>Phase</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="risk-classification">
                {editingPatientDetails ? (
                  <select name="risk_classification" value={editedPatientData.risk_classification} onChange={handlePatientInputChange}>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                ) : (
                  <span className={`risk-classification ${selectedPatient.risk_classification}`}>
                    {selectedPatient.risk_classification}
                  </span>
                )}
              </td>
              <td className="medication">
                {editingPatientDetails ? (
                  <input type="text" name="medication" value={editedPatientData.medication} onChange={handlePatientInputChange} />
                ) : (
                  selectedPatient.medication
                )}
              </td>
              <td className="phase">
                {editingPatientDetails ? (
                  <select name="phase" value={editedPatientData.phase} onChange={handlePatientInputChange}>
                    <option value="Pre-Operative">Pre-Operative</option>
                    <option value="Post-Operative">Post-Operative</option>
                  </select>
                ) : (
                  <span className={`phase ${selectedPatient.phase}`}>
                    {selectedPatient.phase}
                  </span>
                )}
              </td>
            </tr>
          </tbody>
        </table>

        {editingPatientDetails ? (
          <div>
            <button onClick={handleUpdatePatientDetails}>Save</button>
            <button onClick={() => setEditingPatientDetails(false)}>Cancel</button>
          </div>
        ) : (
          <button onClick={() => setEditingPatientDetails(true)}>Edit Patient Details</button>
        )}

        <button onClick={() => setActiveSection("doctor-dashboard")}>Back to Dashboard</button>
      </div>
    );
  };

  return (
    <div className="dashboard-container">
      <div className="fixed-sidebar">
        <h2>Doctor's Dashboard</h2>
        <ul>
          <li onClick={() => setActiveSection("doctor-dashboard")}>Doctor's Dashboard</li>
          {selectedPatient && <li onClick={() => setActiveSection("patient-profile")}>Patient Profile</li>}
          <li onClick={() => setActiveSection("reports")}>Reports</li>
          <li onClick={() => setActiveSection("integrations")}>Integrations</li>
        </ul>
        <h3>Saved Reports</h3>
        <ul>
          <li>Current Month</li>
          <li>Last Quarter</li>
          <li>Social Engagement</li>
        </ul>
        <button className="signout" onClick={handleLogout}>Sign Out</button>
      </div>
      <div className="header">
        <h1>
          <span style={{ color: '#00aaff' }}>DIA</span>
          <span style={{ color: '#ff9800' }}>TRACK</span>
        </h1>
        <div className="search-bar">
          <input
            type="text"
            placeholder="Search patients..."
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
      </div>
      <div className="main-content">
        <h1>Welcome, Dr. {user.first_name}</h1>
        {activeSection === "doctor-dashboard" && renderDoctorDashboard()}
        {activeSection === "patient-profile" && renderPatientProfile()}
      </div>
    </div>
  );
};

export default Dashboard;