import React from "react";
import logo from "../picture/logo.png"; // Adjust the path based on where you store the image

const LandingPage = ({ goToLogin, goToSignUp }) => {
  return (
    <div className="landing-page-container">
      <div className="landing-header">
        {/* Logo Image */}
        <div className="logo">
          <img src={logo} alt="DIATRACK Logo" className="logo-image" />
        </div>
        <div className="title-container">
          <div className="title-text">
            <h1>
              <span style={{ color: '#1FAAED' }}>Dia</span>
              <span style={{ color: '#F8A50D' }}>Track</span>
            </h1>
            <p className="subtitle">A Holistic Diabetes Care Management System</p>
            <p className="subtitle">Integrating Personalized Monitoring, Risk Management</p>
            <p className="subtitle">and Long-Term Health Support</p>
          </div>
          <div className="buttons">
            <button className="Login" onClick={goToLogin}>Login</button>
            <button className="SignUp" onClick={goToSignUp}>SignUp</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;